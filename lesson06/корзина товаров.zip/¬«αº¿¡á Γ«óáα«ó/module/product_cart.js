/*отображение списка товаров*/
console.log('все рабоатет');

// добавить к классу получение данных из локал стораж
// и отображение этих данных

// products = {
//     '1': product1,
//     '2': product2,
//     '3': product3
// };

// document.addEventListener("click", function(event) {
//     //console.log(event);
//     console.log(event.target);
//     if (event.target && event.target.matches(".btn-add-to-cart")) { // опредляем что была нажата кнопка добавить в корзину
//         //console.log(event.target.id)
//         products[event.target.id].save_to_local_storage();
//     }
//     count_items();
// })